#!/bin/sh
#SBATCH --job-name=Salvo_Modified_Stoch
#SBATCH --array=1-500
#SBATCH -N 5
#SBATCH --mem-per-cpu=2048M
#SBATCH --cpus-per-task=5
#SBATCH --output=./Salvo_outputs/print_outputs/Modified_Stoch/Obs%a.txt

. /etc/profile
module load lang/python
source /smallwork/$USER/comp3/bin/activate

python /home/$USER/Salvo_outputs/Salvo_Modified_Stoch_HPC.py ${SLURM_ARRAY_TASK_ID} $USER
