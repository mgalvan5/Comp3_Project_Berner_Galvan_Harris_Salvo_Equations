#To run this app, run "streamlit run <filename>.py" from the command line
#  For example, can run that command from Anaconda PowerShell or a Jupyter Terminal
#Or run "!streamlit run <filename>.py" from a Jupyter cell

import streamlit as st
import os
import paramiko
import pandas as pd
import xlwings as xw
import time
from heatmap_module import heatmap_interaction

st.title('Hughes\' Salvo Equations Modeler')

#### Section: Connect to HPC
st.sidebar.subheader('Connect to HPC',anchor='connect_hpc')
host = 'hamming-sub1.uc.nps.edu'
port = 22
st.sidebar.markdown(f"""Connect to NPS HPC Hamming platform at hostname `{host}` to access and run Hughes\' Lanchester model. """)

username = st.sidebar.text_input('Enter NPS HPC Username')
password = st.sidebar.text_input('Enter NPS HPC Password',type='password')
connected = False

present_dir = os.getcwd()
st.text(present_dir)


if (len(username)>0) & (len(password)>0):
    try:
        client = paramiko.client.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host, username=username, password=password)
        connected = True
    except:
        st.write('''Not able to connect.  Please re-enter username and password, and
        ensure you are on the NPS network or using VPN.''')
  
    if connected:

        def ranges_2_parameters(min, max, levels):
            y = (max - min)/(levels - 1)
            x = min/y
            return round(x,2), round(y,2)

        def generate_DOE(A_val, alpha, a1_val, a3_val, a4_val, sigmaA_val, tauA_val, delA_val, phiA_val, p_A_WAM_val, p_A_DWAM_val, B_val, beta, b1_val, b3_val, b4_val, sigmaB_val, tauB_val, delB_val, phiB_val, p_B_WAM_val, p_B_DWAM_val):

            A_val = ranges_2_parameters(A_val[0],A_val[1],100)
            alpha = ranges_2_parameters(alpha[0],alpha[1],5)
            a1_val = ranges_2_parameters(a1_val[0],a1_val[1],5)
            a3_val = ranges_2_parameters(a3_val[0],a3_val[1],5)

            B_val = ranges_2_parameters(B_val[0],B_val[1],100)
            beta = ranges_2_parameters(beta[0],beta[1],5)
            b1_val = ranges_2_parameters(b1_val[0],b1_val[1],5)
            b3_val = ranges_2_parameters(b3_val[0],b3_val[1],5)

            wb = xw.Book('DOE.xlsx')  # Replace with your file path
            ws = wb.sheets['Translated Design']  # Replace with your sheet name

            # Assign values to the cells
            ws['B4'].value = alpha[0]
            ws['B6'].value = alpha[1]
            ws['C4'].value = beta[0]
            ws['C6'].value = beta[1]
            ws['D4'].value = a1_val[0]
            ws['D6'].value = a1_val[1]
            ws['E4'].value = b1_val[0]
            ws['E6'].value = b1_val[1]
            ws['F4'].value = a3_val[0]
            ws['F6'].value = a3_val[1]
            ws['G4'].value = b3_val[0]
            ws['G6'].value = b3_val[1]
            ws['H4'].value = A_val[0]
            ws['H6'].value = A_val[1]
            ws['I4'].value = B_val[0]
            ws['I6'].value = B_val[1]

            ws['J4'].value = a4_val[1]
            ws['J5'].value = a4_val[0]
            ws['K4'].value = b4_val[1]
            ws['K5'].value = b4_val[0]
            ws['L4'].value = sigmaA_val[1]
            ws['L5'].value = sigmaA_val[0]
            ws['M4'].value = sigmaB_val[1]
            ws['M5'].value = sigmaB_val[0]
            ws['N4'].value = tauA_val[1]
            ws['N5'].value = tauA_val[0]
            ws['O4'].value = tauB_val[1]
            ws['O5'].value = tauB_val[0]
            ws['P4'].value = delA_val[1]
            ws['P5'].value = delA_val[0]
            ws['Q4'].value = delB_val[1]
            ws['Q5'].value = delB_val[0]
            ws['R4'].value = phiA_val[1]
            ws['R5'].value = phiA_val[0]
            ws['S4'].value = phiB_val[1]
            ws['S5'].value = phiB_val[0]
            ws['T4'].value = p_A_WAM_val[1]
            ws['T5'].value = p_A_WAM_val[0]
            ws['U4'].value = p_B_WAM_val[1]
            ws['U5'].value = p_B_WAM_val[0]
            ws['V4'].value = p_A_DWAM_val[1]
            ws['V5'].value = p_A_DWAM_val[0]
            ws['W4'].value = p_B_DWAM_val[1]
            ws['W5'].value = p_B_DWAM_val[0]

            # Get all values from the worksheet
            data = ws.range('B7:W2007').expand().value  # Adjust the range as necessary

            # Convert to DataFrame
            columns = data[0]  # The first row as the header
            df = pd.DataFrame(data[1:], columns=columns)  # Create DataFrame from the data excluding the header

            # Close the workbook
            wb.close()

            # Now df contains the evaluated values
            df.to_csv('sim_DOE.csv', index=False)

            return None
        
        def prep_model(model, client, username):
            channel = client.invoke_shell()
            try:
                channel.send(f"rm -rf /home/{username}/Salvo_outputs\n")
                time.sleep(10)
                # Allocate resources
                channel.send("salloc --mem=32GB\n")
                time.sleep(5)  # Wait for allocation to be potentially ready
                channel.send(f"source /smallwork/{username}/comp3/bin/activate\n")
                time.sleep(1)

                # Ensure the directory creation
                directory = f"/home/{username}/Salvo_outputs/data_output/{model}"
                channel.send(f"mkdir -p {directory}\n")
                channel.send(f"mkdir -p /home/{username}/Salvo_outputs/print_outputs/{model}\n")
                time.sleep(5)  # Wait for mkdir to complete
                channel.send(f"ls {directory}\n")
                time.sleep(2)  # Give time to list the directory

                # Check directory creation
                while channel.recv_ready():
                    response = channel.recv(4096).decode('utf-8')
                    if 'cannot access' in response:
                        raise Exception("Failed to create directory on remote server")
            except Exception as e:
                print(f"An error occurred: {e}")
            finally:
                channel.close()
        
        def run_model(present_dir, model, client, username):
            with client.invoke_shell() as channel:
                # Initialize a placeholder for messages
                output_placeholder = st.empty()

                try:
                    output_placeholder.text("Allocating resources...")
                    channel.send("salloc --mem=32GB \n")
                    time.sleep(5)  # Time to allocate resources

                    output_placeholder.text("Activating Python environment...")
                    channel.send(f"source /smallwork/{username}/comp3/bin/activate\n")
                    time.sleep(2)

                    output_placeholder.text("Transferring files via SFTP...")
                    with client.open_sftp() as sftp:
                        sftp.put(f"{present_dir}/{model}_HPC.py", f"/home/{username}/Salvo_outputs/{model}_HPC.py")
                        # Update as each file is transferred
                        output_placeholder.text(f"Transferred {model}_HPC.py")
                        # Repeat for other files
                        sftp.put(f"{present_dir}/sim_DOE.csv", f"/home/{username}/Salvo_outputs/sim_DOE.csv")
                        output_placeholder.text(f"Transferred sim_DOE.csv")

                        sftp.put(f"{present_dir}/batch_{model}.sh", f"/home/{username}/Salvo_outputs/batch_{model}.sh")
                        output_placeholder.text(f"Transferred batch_{model}.sh")

                        sftp.put(f"{present_dir}/robust_analysis_{model}.py", f"/home/{username}/Salvo_outputs/robust_analysis_{model}.py")
                        output_placeholder.text(f"Transferred robust_analysis_{model}.py")

                        sftp.put(f"{present_dir}/robust_{model}.sh", f"/home/{username}/Salvo_outputs/robust_{model}.sh")
                        output_placeholder.text(f"Transferred robust_{model}.sh")

                    output_placeholder.text("Setting execute permissions for all files...")
                    channel.send(f"chmod +x /home/{username}/Salvo_outputs/*\n")
                    time.sleep(2)

                    output_placeholder.text("Submitting job...")
                    channel.send(f"sbatch /home/{username}/Salvo_outputs/batch_{model}.sh\n")
                    time.sleep(10)
                    output = channel.recv(9999).decode()
                    job_id = output.strip().split()[-1]
                    output_placeholder.text(f"Job {job_id} submitted.")

                    output_placeholder.text("Monitoring job status...")
                    finished = False
                    while not finished:
                        channel.send(f"squeue -j {job_id}\n") #Bash code for num files in data_outputs 
                        time.sleep(5)
                        output = channel.recv(9999).decode()
                        if "PD" not in output and "R" not in output:
                            finished = True
                            output_placeholder.text("Job completed.")
                except Exception as e:
                    output_placeholder.text(f"Error: {e}")
                finally:
                    sftp.close()
                    channel.close()
        
        def run_robust(present_dir, model, client, username):
            with client.invoke_shell() as channel:
                output_placeholder = st.empty()  # Placeholder for dynamic updates

                try:
                    output_placeholder.text("Allocating resources...")
                    channel.send("salloc --mem=32GB\n")
                    time.sleep(5)  # Assume resource allocation time

                    output_placeholder.text("Activating Python environment...")
                    channel.send(f"source /smallwork/{username}/comp3/bin/activate\n")
                    time.sleep(2)

                    output_placeholder.text("Submitting robust analysis job...")
                    channel.send(f"sbatch /home/{username}/Salvo_outputs/robust_{model}.sh\n")
                    time.sleep(10)  # Wait for sbatch to process
                    output = channel.recv(9999).decode()
                    job_id = output.strip().split()[-1]
                    output_placeholder.text(f"Job {job_id} submitted for robust analysis.")

                    # Monitor job status
                    output_placeholder.text("Monitoring job status...")
                    finished = False
                    while not finished:                  #Create similar error check to above function for num files
                        channel.send(f"squeue -j {job_id}\n")
                        time.sleep(5)  # Check job status every 5 seconds
                        output = channel.recv(9999).decode()
                        if "PD" not in output and "R" not in output:
                            finished = True
                            output_placeholder.text("Robustness analysis completed successfully.")
                except Exception as e:
                    output_placeholder.text(f"Error occurred: {e}")
                finally:
                    channel.close()
        
        def transfer_outputs(present_dir, model, client, username):
            with client.invoke_shell() as channel:
                output_placeholder = st.empty()

                try:
                    sftp = client.open_sftp()
                    output_placeholder.text("Waiting for file... (This may take several minutes)")
                    # Ensure file exists before trying to get
                    try:
                        #start_time = time.time()
                        file_exists = False
                        while not file_exists:
                            try:
                                sftp.stat(f"/home/{username}/Salvo_outputs/sim_DOE_results_{model}.csv")
                                file_exists = True
                                if file_exists == True:
                                    channel.send(f"chmod +wrx /home/{username}/Salvo_outputs/*\n")
                                    transfer_path = os.path.join(present_dir, f'sim_DOE_results_{model}.csv')
                                    sftp.get(f"/home/{username}/Salvo_outputs/sim_DOE_results_{model}.csv", transfer_path)
                                    #sftp.get(f"/home/{username}/Salvo_outputs/sim_DOE_results_{model}.csv", present_dir)
                                    output_placeholder.text("Transferring output file...")
                                    time.sleep(1)
                            except IOError:
                                time.sleep(10)
                                # Check if the timeout has elapsed
                                #if time.time() - start_time > 180:
                                    #break

                    except IOError:
                        output_placeholder.text("File does not exist or could not be accessed.")
                    
                    # Delete all outputs after successful transfer
                    #channel.send(f"rm -rf /home/{username}/Salvo_outputs\n")
                    #output_placeholder.text("Clearing Files...")
                    time.sleep(10)
                except Exception as e:
                    output_placeholder.text(f"Error occurred: {e}")
                finally:
                    sftp.close()
                    channel.close()
                    output_placeholder.text("Model Complete!")
            
st.subheader('Model Selection')
st.markdown(f"""Choose the model you want to run. """)

model = st.selectbox(
    "Choose the salvo model you want to run:",
    ["Salvo_Basic", "Salvo_Basic_Stoch", "Salvo_Modified", "Salvo_Modified_Stoch"]
)

if 'model_complete' not in st.session_state:
    st.session_state.model_complete = False

st.subheader('Enter Model Inputs')
st.markdown(f"""Input all of the necessary values of the model you intend to run. """)
        
col1, col2 = st.columns(2)

col1.header("Force A")
col2.header("Force B")

# Place number inputs in each column
with col1:
    A_val_min = st.number_input("Initial A Force Min", min_value=1, max_value=10000, value=10)
    A_val_max = st.number_input("Initial A Force Max", min_value=1, max_value=10000, value=20)
    alpha = st.slider("Well aimed missiles fired by A", 0, 100, (4,10))
    a1_val = st.slider("number of hits by B's missiles needed to put one A unit out of action", 0, 100, (3,6))
    a3_val = st.slider("number of well aimed missiles destroyed by each A", 0, 100, (2,4))
    a4_val = st.slider("probability that accurate shots miss after counterfire by the enemy has failed A", 0.0, 1.0, (0.5,0.8))
    sigmaA_val = st.slider("Scouting Effectiveness A", 0.0, 1.0, (0.9,1.0))
    tauA_val = st.slider("Training Effectiveness A", 0.0, 1.0, (0.9,1.0))
    delA_val = st.slider("Alertness of Defenses A", 0.0, 1.0, (0.9,1.0))
    phiA_val = st.slider("Alertness of Chaff A", 0.0, 1.0, (0.9,1.0))
    p_A_WAM_val = st.slider("Probability of a Missile Being Accurately Aimed on a Force B Target", 0.0, 1.0, (0.9,1.0))
    p_A_DWAM_val = st.slider("Probability of a Missile Fired by Force B is Destroyed", 0.0, 1.0, (0.9,1.0))

with col2:
    B_val_min = st.number_input("Initial B Force Min", min_value=1, max_value=10000, value=10)
    B_val_max = st.number_input("Initial B Force Max", min_value=1, max_value=10000, value=20)
    beta = st.slider("Well aimed missiles fired by B", 0, 100, (4,10))
    b1_val = st.slider("number of hits by A's missiles needed to put one B unit out of action", 0, 100, (3,6))
    b3_val = st.slider("number of well aimed missiles destroyed by each B", 0, 100, (2,4))
    b4_val = st.slider("probability that accurate shots miss after counterfire by the enemy has failed B", 0.0, 1.0, (0.5,0.8))
    sigmaB_val = st.slider("Scouting Effectiveness B", 0.0, 1.0, (0.9,1.0))
    tauB_val = st.slider("Training Effectiveness B", 0.0, 1.0, (0.9,1.0))
    delB_val = st.slider("Alertness of Defenses B", 0.0, 1.0, (0.9,1.0))
    phiB_val = st.slider("Alertness of Chaff B", 0.0, 1.0, (0.9,1.0))
    p_B_WAM_val = st.slider("Probability of a Missile Being Accurately Aimed on a Force A Target", 0.0, 1.0, (0.9,1.0))
    p_B_DWAM_val = st.slider("Probability of a Missile Fired by Force A is Destroyed", 0.0, 1.0, (0.9,1.0))

A_val = (A_val_min, A_val_max)
B_val = (B_val_min, B_val_max)

#Run sample commands to verify connection
if st.button('Generate DOE and Prep Model'):
    if connected:
        generate_DOE(A_val, alpha, a1_val, a3_val, a4_val, sigmaA_val, tauA_val, delA_val, phiA_val, p_A_WAM_val, p_A_DWAM_val, B_val, beta, b1_val, b3_val, b4_val, sigmaB_val, tauB_val, delB_val, phiB_val, p_B_WAM_val, p_B_DWAM_val)
        prep_model(model, client, username)
        st.session_state.model_complete = False
    else:
        st.write('Connect to HPC and try again.')

if st.button('Run Model'):
    if connected:
        
        run_model(present_dir, model, client, username)
        run_robust(present_dir, model, client, username)
        transfer_outputs(present_dir, model, client, username)

        st.session_state.model_complete = True

    else:
        st.write('Connect to HPC and try again.')


if st.session_state.model_complete:
    st.subheader('Model Heatmap Analysis')
    base_path = present_dir  # Set this to the correct path
    file_name = f'sim_DOE_results_{model}.csv'  # Adjust the file name as needed
    heatmap_interaction(base_path, file_name)


