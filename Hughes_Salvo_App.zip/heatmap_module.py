import streamlit as st
import pandas as pd
import plotly.express as px
import os

def load_data(filepath):
    return pd.read_csv(filepath)

def plot_heatmap(df, x_axis, y_axis, output):
    min_value = df[output].min()
    max_value = df[output].max()

    fig = px.density_heatmap(
        df, x=x_axis, y=y_axis, z=output, nbinsx=20, nbinsy=20,
        color_continuous_scale="Purples",
        range_color=[min_value, max_value]
    )
    fig.update_layout(
        title=f"Heatmap of {x_axis} vs {y_axis} with {output} as Color",
        xaxis_title=x_axis,
        yaxis_title=y_axis,
        coloraxis_colorbar=dict(title=output)
    )
    return fig

def heatmap_interaction(base_path, file_name):   
    st.header("Interactive Heatmap")

    file_path = os.path.join(base_path, file_name)
    df = load_data(file_path)

    # Define keys for session state
    keys = ['x_axis', 'y_axis', 'output']

    # Check if data is loaded and not None
    if df is not None:
        if not all(key in st.session_state for key in keys):
            # Initialize session state if not present
            st.session_state['x_axis'] = df.columns[0]
            st.session_state['y_axis'] = df.columns[1]
            st.session_state['output'] = df.columns[24]

        # Selection dropdowns that bind directly to session_state
        x_axis = st.selectbox("Select X-axis:", options=df.columns[:23], index=0, key='x_axis')
        y_axis = st.selectbox("Select Y-axis:", options=df.columns[:23], index=1, key='y_axis')
        output = st.selectbox("Select Output for Color Scale:", options=df.columns[24:44], index=0, key='output')

        if st.button("Generate Heatmap"):
            fig = plot_heatmap(df, x_axis, y_axis, output)
            st.plotly_chart(fig)


