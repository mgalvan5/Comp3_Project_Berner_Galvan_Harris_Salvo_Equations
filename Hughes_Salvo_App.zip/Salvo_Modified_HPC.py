import random
import math
import pandas as pd # type: ignore
import numpy.random as rd # type: ignore
from scipy.stats import bernoulli # type: ignore
import sys
from datetime import datetime
import json

#Print current time
now = datetime.now()
current_time = now.strftime("%D %H:%M:%S")
print("Running ",sys.argv[0]) #sys.argv[0] is name of current script
print("Current Time = ", current_time)

#Specify whether to print battle info for every epoch
verbose = False

#Function to return parameters for runs
def round_negatives(equation):
    """The comparison of fighting strengths cannot be negative. If the result is negative, the defense is too strong and no damage is done by the attacker, and a 0 loss results."""
    if equation < 0:
        return 0
    else:
        return equation
    
def FER(delta_A, delta_B, A, B):
    """ 
    Description: Fractional Exchange Ratio (FER) is the measure of effectiveness between units A and B
    Inputs:
        delta_A: number of units in force A out of action from B's salvo.
        delta_B: number of units in force B out of action from A's salvo.
        A: initial number of units in force A
        B: initial number of units in force B
    Outputs:
        FER: the ratio of fractional losses after A and be exchange salvoes
    """
    try:
        return ((delta_B/B)/(delta_A/A))
    except ZeroDivisionError:
        return None
    
def modified_coeffs(alpha, beta, a3, b3, sigma_a=1, sigma_b=1, tau_a=1, tau_b=1, del_a=1, del_b=1, phi_a=1, phi_b=1):
    """
    Description: Fighting power in hits of an attacking unit of each side modified for the attacker's scouting and training deficiencies and the effect of defender's distraction chaff.
    Inputs: 
        alpha: initial number of well aimed missiles fired by each A unit.
        beta: initial number of well aimed missiles fired by each B unit.
        a3: initial number of well aimed missiles destroyed by each A unit.
        b3: initial number of well aimed missiles destroyed by each B unit.
        sigma_a: scouting effectiveness due to less than perfect targeting of A units.
        sigma_b: scouting effectiveness due to less than perfect targeting of B units.
        tau_a: training effectiveness of A units.
        tau_b: training effectiveness of B units.
        del_a: alertness of unit A's defense that is degraded by less than perfect readiness or fire control.
        del_b: alertness of unit B's defense that is degraded by less than perfect readiness or fire control.
        phi_a: effectiveness of unit A chaff that draws off shots before its counterfire against B's missiles.
        phi_b: effectiveness of unit B chaff that draws off shots before its counterfire against A's missiles.
    Outputs:
        alpha_prime: A units fighting power in hits that is modified for scouting, training, and unit B's distraction chaff.
        beta_prime: B units fighting power in hits that is modified for scouting, training, and unit A's distraction chaff.
        a3_prime: resulting number of well aimed missiles destroyed by each A unit.
        b3_prime: resulting number of well aimed missiles destroyed by each B unit.
    """
    
    alpha_prime = sigma_a*tau_a*phi_b*alpha
    beta_prime = sigma_b*tau_b*phi_a*beta
    a3_prime = del_a*tau_a*a3
    b3_prime = del_b*tau_b*b3

    return alpha_prime, beta_prime, a3_prime, b3_prime
    
def modified_salvo(A, B, alpha, beta, a1, b1, a3, b3, a4, b4, sigma_a=1, sigma_b=1, tau_a=1, tau_b=1, del_a=1, del_b=1, phi_a=1, phi_b=1, verbose=True):
    """
    Description: Calculate how many units for A and B are estimated to be out of action after expending their salvos.
    Inputs:
        A: initial number of units in force A 
        B: initial number of units in force B
        alpha: number of well aimed missiles fired by each A unit.
        beta: number of well aimed missiles fired by each B unit.
        a1: number of hits by B's missiles needed to put one A unit out of action.
        b1: number of hits by A's missiles needed to put one B unit out of action.
        a3: number of well aimed missiles destroyed by each A.
        b3: number of well aimed missiles destroyed by each B.
        a4: probability that accurate shots miss after counterfire by the enemy has failed.
        b4: probability that accurate shots miss after counterfire by the enemy has failed.
        sigma_a: scouting effectiveness due to less than perfect targeting of A units.
        sigma_b: scouting effectiveness due to less than perfect targeting of B units.
        tau_a: training effectiveness of A units.
        tau_b: training effectiveness of B units.
        del_a: alertness of unit A's defense that is degraded by less than perfect readiness or fire control.
        del_b: alertness of unit B's defense that is degraded by less than perfect readiness or fire control.
        phi_a: effectiveness of unit A chaff that draws off shots before its counterfire against B's missiles.
        phi_b: effectiveness of unit B chaff that draws off shots before its counterfire against A's missiles.
    Outputs:
        delta_A: number of units in force A out of action from B's salvo.
        delta_B: number of units in force B out of action from A's salvo.
        A: initial number of units in force A 
        B: initial number of units in force B
    """
    alpha_prime, beta_prime, a3_prime, b3_prime = modified_coeffs(alpha, beta, a3, b3, sigma_a, sigma_b, tau_a, tau_b, del_a, del_b, phi_a, phi_b)

    
    if round_negatives(((a1/a4)*alpha_prime*(A**2)) - ((a1/a4)*A*b3_prime*B)) > round_negatives(((b1/b4)*beta_prime*(B**2))-((b1/b4)*B*a3_prime*A)):
        winner = "A"
        if verbose:
            print("A wins the salvo exchange.")
    elif round_negatives(((a1/a4)*alpha_prime*(A**2)) - ((a1/a4)*A*b3_prime*B)) < round_negatives(((b1/b4)*beta_prime*(B**2))-((b1/b4)*B*a3_prime*A)):
        winner = "B"
        if verbose:
            print("B wins the salvo exchange.")  
    else:
        winner = "Tie" 

    delta_A = (((beta_prime*B)-(a3_prime*A))*a4)/a1
    delta_B = (((alpha_prime*A)-(b3_prime*B))*b4)/b1
    
    if delta_A > A:
        delta_A = A

    if delta_A < 0:
        delta_A = 0
        
    if delta_B > B:
        delta_B = B

    if delta_B < 0:
        delta_B = 0

    delta_A = math.ceil(delta_A)
    delta_B = math.ceil(delta_B)
    
    return delta_A, delta_B, winner

#Initial Conditions should be fed into python script
if len(sys.argv) > 2:
    user_name = str(sys.argv[2])
    observation = int(sys.argv[1])

else:
    #Not enough inputs. Using default index.
    observation = 1
    user_name = str(sys.argv[1])

# Import .csv with DOE parameters
df_DOE = pd.read_csv(f'/home/{user_name}/Salvo_outputs/sim_DOE.csv')
df_DOE.index += 1

random.seed(observation)
results_overall = []

for index, row in df_DOE.iterrows():
    A_0 = int(row.loc["A_0"])
    B_0 = int(row.loc["B_0"])
    alpha = int(row.loc["alpha"])
    beta = int(row.loc["beta"])
    a1 = int(row.loc["a1"])
    b1 = int(row.loc["b1"])
    a3 = int(row.loc["a3"])
    b3 = int(row.loc["b3"])
    a4 = float(row.loc["a4"])
    b4 = float(row.loc["b4"])
    sigma_a = float(row.loc["sigma_A"])
    sigma_b = float(row.loc["sigma_B"])
    tau_a = float(row.loc["tau_A"])
    tau_b = float(row.loc["tau_B"])
    del_a = float(row.loc["del_A"])
    del_b = float(row.loc["del_B"])
    phi_a = float(row.loc["phi_A"])
    phi_b = float(row.loc["phi_B"])
    #prob_WAM_A = float(row.loc["p_A_WAM"])
    #prob_WAM_B = float(row.loc["p_B_WAM"])
    #prob_DWAM_A = float(row.loc["p_A_DWAM"])
    #prob_DWAM_B = float(row.loc["p_B_DWAM"])
    A = A_0
    B = B_0
    
    iter = 0
    A_wins = 0
    B_wins = 0
    Ties = 0
    delta_A_total = 0
    delta_B_total = 0
    results = []
      
    while A > 0 and B > 0:
        iter += 1
        A_exchange = random.randint(1,math.ceil(A/2))
        B_exchange = random.randint(1,math.ceil(B/2))

        delta_A, delta_B, winner = modified_salvo(A=A_exchange, B=B_exchange, alpha=alpha, beta=beta, a1=a1, b1=b1, a3=a3, b3=b3, a4=a4, b4=b4, sigma_a=sigma_a, sigma_b=sigma_b, tau_a=tau_a, tau_b=tau_b, del_a=del_a, del_b=del_b, phi_a=phi_a, phi_b=phi_b, verbose=verbose)
        #print(f'\nBattle Report {iter}: (A: {A_exchange} / B: {B_exchange})')  
        #print(f'   FER: {FER(delta_A, delta_B, A_exchange, B_exchange)}.')
        FER_exchange = FER(delta_A, delta_B, A_exchange, B_exchange)  
        A -= delta_A
        delta_A_total += delta_A
        B -= delta_B   
        delta_B_total += delta_B
        if winner == 'A':
            A_wins += 1
        if winner == 'B':
            B_wins += 1
        if winner == "Tie":
            Ties += 1 
        #print(f'   Force A lost {delta_A} and {A_exchange - delta_A} survived. {A} remaining.')
        #print(f'   Force B lost {delta_B} and {B_exchange - delta_B} survived. {B} remaining.')

        results.append({
            'index': index,
            'exchange': iter,
            'FER': FER_exchange,
            'delta_A': delta_A,
            'delta_B': delta_B,
            'winner': winner
        })

    # Convert the list to a DataFrame
    df = pd.DataFrame(results)

    # Write the DataFrame to a .csv file
    ######df.to_csv(f'results_dicrete_basic_SC{index}_Obs{argv}.csv', index=False)

    if A == 0 and B == 0:
        winner = "Tie"
    elif A > 0: 
        winner = "A"
    else:
        winner = "B"

    results_overall.append({
        'index': index,
        'remaining_A': A,
        'remaining_B': B,
        'delta_A': delta_A_total,
        'delta_B': delta_B_total,
        'total_wins_A': A_wins,
        'total_wins_B': B_wins,
        'total_exchanges': iter,
        'winner': winner
    })

df_overall = pd.DataFrame(results_overall)
dummies = pd.get_dummies(df_overall['winner'], prefix='', prefix_sep='')
if len(dummies.columns) == 2:
    dummies.columns = ['winner_A', 'winner_B']
    dummies['Tie'] = 0
else:
    dummies.columns = ['winner_A', 'winner_B', 'Tie']
result_df_overall = pd.concat([df_overall, dummies], axis=1)
result_df_overall = result_df_overall.drop('winner', axis=1)
result_df_overall = result_df_overall.astype(int)


# Save final outputs as dictionary in "output" variable
for i, row in result_df_overall.iterrows():
    index = int(row.loc['index'])
    output = {
        'remaining_A': int(row.loc['remaining_A']),
        'remaining_B': int(row.loc['remaining_B']),
        'delta_A': int(row.loc['delta_A']),
        'delta_B': int(row.loc['delta_B']),
        'total_wins_A': int(row.loc['total_wins_A']),
        'total_wins_B': int(row.loc['total_wins_B']),
        'total_exchanges': int(row.loc['total_exchanges']),
        'winner_A': int(row.loc['winner_A']),
        'winner_B': int(row.loc['winner_B']),
        'tie': int(row.loc['Tie']),
    }
    # Save to JSON file
    with open(f'/home/{user_name}/Salvo_outputs/data_output/Salvo_Modified/DP{index}_Obsv{observation}.json', 'w') as json_file:
        json.dump(output, json_file)
    print(f'\n{output}')
