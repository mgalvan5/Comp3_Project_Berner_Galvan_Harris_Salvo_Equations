#!/bin/sh
#SBATCH --job-name=Robust_Salvo_Basic_Stoch
#SBATCH --mem-per-cpu=4096M
#SBATCH --cpus-per-task=1
#SBATCH --output=./Salvo_outputs/print_outputs/RobustBasicStoch%a.txt

. /etc/profile
module load lang/python
source /smallwork/$USER/comp3/bin/activate

python /home/$USER/Salvo_outputs/robust_analysis_Salvo_Basic_Stoch.py $USER
