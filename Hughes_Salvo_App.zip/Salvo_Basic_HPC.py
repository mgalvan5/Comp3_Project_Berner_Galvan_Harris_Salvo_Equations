import random
import math
import pandas as pd # type: ignore
import numpy.random as rd # type: ignore
from scipy.stats import bernoulli # type: ignore
import sys
from datetime import datetime
import json

#Print current time
now = datetime.now()
current_time = now.strftime("%D %H:%M:%S")
print("Running ",sys.argv[0]) #sys.argv[0] is name of current script
print("Current Time = ", current_time)

#Specify whether to print battle info for every epoch
verbose = False

#Function to return parameters for runs
def round_negatives(equation):
    """The comparison of fighting strengths cannot be negative. If the result is negative, the defense is too strong and no damage is done by the attacker, and a 0 loss results."""
    if equation < 0:
        return 0
    else:
        return equation
    
def FER(delta_A, delta_B, A, B):
    """ 
    Description: Fractional Exchange Ratio (FER) is the measure of effectiveness between units A and B
    Inputs:
        delta_A: number of units in force A out of action from B's salvo.
        delta_B: number of units in force B out of action from A's salvo.
        A: initial number of units in force A
        B: initial number of units in force B
    Outputs:
        FER: the ratio of fractional losses after A and be exchange salvoes
    """
    try:
        return ((delta_B/B)/(delta_A/A))
    except ZeroDivisionError:
        return None
    
def basic_salvo(A, B, alpha, beta, a1, b1, a3, b3, verbose=True):
    """
    Description: Calculate how many units for A and B are estimated to be out of action after expending their salvos.
    Inputs:
        A: initial number of units in force A 
        B: initial number of units in force B
        alpha: number of well aimed missiles fired by each A unit.
        beta: number of well aimed missiles fired by each B unit.
        a1: number of hits by B's missiles needed to put one A unit out of action.
        b1: number of hits by A's missiles needed to put one B unit out of action.
        a3: number of well aimed missiles destroyed by each A.
        b3: number of well aimed missiles destroyed by each B.
    Outputs:
        delta_A: number of units in force A out of action from B's salvo.
        delta_B: number of units in force B out of action from A's salvo.
        A: initial number of units in force A 
        B: initial number of units in force B
    """
    if round_negatives((a1*alpha*(A**2)) - (a1*A*b3*B)) > round_negatives((b1*beta*(B**2))-(b1*B*a3*A)):
        winner = "A"
        if verbose:
            print("A wins the salvo exchange.")
    elif round_negatives((a1*alpha*(A**2)) - (a1*A*b3*B)) < round_negatives((b1*beta*(B**2))-(b1*B*a3*A)):
        winner = "B"
        if verbose:
            print("B wins the salvo exchange.")  
    else:
        winner = "Tie" 
        if verbose:
            print("The salvo exchange ends in a tie.")  

    delta_A = ((beta*B)-(a3*A))/a1
    delta_B = ((alpha*A)-(b3*B))/b1

    if delta_A > A:
        delta_A = A

    if delta_A < 0:
        delta_A = 0
        
    if delta_B > B:
        delta_B = B

    if delta_B < 0:
        delta_B = 0

    delta_A = math.ceil(delta_A)
    delta_B = math.ceil(delta_B)
    
    return delta_A, delta_B, winner

#Initial Conditions should be fed into python script
if len(sys.argv) > 2:
    user_name = str(sys.argv[2])
    observation = int(sys.argv[1])

else:
    #Not enough inputs. Using default index.
    observation = 1
    user_name = str(sys.argv[1])

# Import .csv with DOE parameters
df_DOE = pd.read_csv(f'/home/{user_name}/Salvo_outputs/sim_DOE.csv')
df_DOE.index += 1

random.seed(observation)
results_overall = []

for index, row in df_DOE.iterrows():
    A_0 = int(row.loc["A_0"])
    B_0 = int(row.loc["B_0"])
    alpha = int(row.loc["alpha"])
    beta = int(row.loc["beta"])
    a1 = int(row.loc["a1"])
    b1 = int(row.loc["b1"])
    a3 = int(row.loc["a3"])
    b3 = int(row.loc["b3"])
    #a4 = float(row.loc["a4"])
    #b4 = float(row.loc["b4"])
    #sigma_a = float(row.loc["sigma_A"])
    #sigma_b = float(row.loc["sigma_B"])
    #tau_a = float(row.loc["tau_A"])
    #tau_b = float(row.loc["tau_B"])
    #del_a = float(row.loc["del_A"])
    #del_b = float(row.loc["del_B"])
    #phi_a = float(row.loc["phi_A"])
    #phi_b = float(row.loc["phi_B"])
    #prob_WAM_A = float(row.loc["p_A_WAM"])
    #prob_WAM_B = float(row.loc["p_B_WAM"])
    #prob_DWAM_A = float(row.loc["p_A_DWAM"])
    #prob_DWAM_B = float(row.loc["p_B_DWAM"])
    A = A_0
    B = B_0
    
    iter = 0
    A_wins = 0
    B_wins = 0
    Ties = 0
    delta_A_total = 0
    delta_B_total = 0
    results = []

    while A > 0 and B > 0:
        iter += 1
        A_exchange = random.randint(1,math.ceil(A/2))
        B_exchange = random.randint(1,math.ceil(B/2))

        delta_A, delta_B, winner = basic_salvo(A=A_exchange, B=B_exchange, alpha=alpha, beta=beta, a1=a1, b1=b1, a3=a3, b3=b3, verbose=verbose)
        FER_exchange = FER(delta_A, delta_B, A_exchange, B_exchange)
        #print(f'\nBattle Report {iter}: (A: {A_exchange} / B: {B_exchange})')  
        #print(f'   FER: {FER_exchange}')  
        A -= delta_A
        delta_A_total += delta_A
        B -= delta_B   
        delta_B_total += delta_B
        if winner == 'A':
            A_wins += 1
        if winner == 'B':
            B_wins += 1
        if winner == "Tie":
            Ties += 1

        #print(f'   Force A lost {delta_A} and {A_exchange - delta_A} survived. {A} remaining.')
        #print(f'   Force B lost {delta_B} and {B_exchange - delta_B} survived. {B} remaining.')
        
        results.append({
            'index': index,
            'exchange': iter,
            'FER': FER_exchange,
            'delta_A': delta_A,
            'delta_B': delta_B,
            'winner': winner
        })

    # Convert the list to a DataFrame
    df = pd.DataFrame(results)

    # Write the DataFrame to a .csv file
    ######df.to_csv(f'results_dicrete_basic_SC{index}_Obs{argv}.csv', index=False)

    if A == 0 and B == 0:
        winner = "Tie"
    elif A > 0: 
        winner = "A"
    else:
        winner = "B"

    results_overall.append({
        'index': index,
        'remaining_A': A,
        'remaining_B': B,
        'delta_A': delta_A_total,
        'delta_B': delta_B_total,
        'total_wins_A': A_wins,
        'total_wins_B': B_wins,
        'total_exchanges': iter,
        'winner': winner
    })

df_overall = pd.DataFrame(results_overall)
dummies = pd.get_dummies(df_overall['winner'], prefix='', prefix_sep='')
if len(dummies.columns) == 2:
    dummies.columns = ['winner_A', 'winner_B']
    dummies['Tie'] = 0
else:
    dummies.columns = ['winner_A', 'winner_B', 'Tie']
result_df_overall = pd.concat([df_overall, dummies], axis=1)
result_df_overall = result_df_overall.drop('winner', axis=1)
result_df_overall = result_df_overall.astype(int)


# Save final outputs as dictionary in "output" variable
for i, row in result_df_overall.iterrows():
    index = int(row.loc['index'])
    output = {
        'remaining_A': int(row.loc['remaining_A']),
        'remaining_B': int(row.loc['remaining_B']),
        'delta_A': int(row.loc['delta_A']),
        'delta_B': int(row.loc['delta_B']),
        'total_wins_A': int(row.loc['total_wins_A']),
        'total_wins_B': int(row.loc['total_wins_B']),
        'total_exchanges': int(row.loc['total_exchanges']),
        'winner_A': int(row.loc['winner_A']),
        'winner_B': int(row.loc['winner_B']),
        'tie': int(row.loc['Tie']),
    }
    # Save to JSON file
    #with open(f'./data_output/Salvo_Basic/DP{index}_Obsv{observation}.json', 'w') as json_file:
    with open(f'/home/{user_name}/Salvo_outputs/data_output/Salvo_Basic/DP{index}_Obsv{observation}.json', 'w') as json_file: #look at file path
        json.dump(output, json_file)
    print(f'\n{output}')
