import os
import pandas as pd # type: ignore
import json
import statistics
import sys

def FER_across_DP(data_dict, DP):
    try:
        delta_B = sum(data_dict[DP]['delta_B'])
        B = sum(data_dict[DP]['delta_B']) + sum(data_dict[DP]['remaining_B'])
        delta_A = sum(data_dict[DP]['delta_A'])
        A = sum(data_dict[DP]['delta_A']) + sum(data_dict[DP]['remaining_A'])
        return (delta_B/B) / (delta_A/A)
    except:
        return None

data_dict = dict()
user_name = str(sys.argv[1])

for filename in os.listdir(f'/home/{user_name}/Salvo_outputs/data_output/Salvo_Modified_Stoch/'):
    if filename.endswith(".json"):
        DP = int(filename.split('_')[0][2:])
        obs_number = int(filename.split('_')[1].split('.')[0][4:])
        
        with open(os.path.join(f'/home/{user_name}/Salvo_outputs/data_output/Salvo_Modified_Stoch/', filename), 'r') as f:
            json_data = json.load(f)
        try: 
            data_dict[DP]['remaining_A'].append(json_data['remaining_A'])
            data_dict[DP]['remaining_B'].append(json_data['remaining_B'])
            data_dict[DP]['delta_A'].append(json_data['delta_A'])
            data_dict[DP]['delta_B'].append(json_data['delta_B'])
            data_dict[DP]['total_wins_A'].append(json_data['total_wins_A'])
            data_dict[DP]['total_wins_B'].append(json_data['total_wins_B'])
            data_dict[DP]['total_exchanges'].append(json_data['total_exchanges'])
            data_dict[DP]['winner_A'].append(json_data['winner_A'])
            data_dict[DP]['winner_B'].append(json_data['winner_B'])
            data_dict[DP]['tie'].append(json_data['tie'])       

        except:    
            data_dict[DP]= {
                'remaining_A': [json_data['remaining_A']],
                'remaining_B': [json_data['remaining_B']],
                'delta_A': [json_data['delta_A']],
                'delta_B': [json_data['delta_B']], 
                'total_wins_A': [json_data['total_wins_A']],
                'total_wins_B': [json_data['total_wins_B']],
                'total_exchanges': [json_data['total_exchanges']],
                'winner_A': [json_data['winner_A']],
                'winner_B': [json_data['winner_B']],
                'tie': [json_data['tie']]
                }
        
outputs = []

for DP in data_dict.keys():
    data = {
        'index': DP,
        'avg_remaining_A': statistics.mean(data_dict[DP]['remaining_A']),
        'sd_remaining_A': statistics.stdev(data_dict[DP]['remaining_A']),
        'avg_remaining_B': statistics.mean(data_dict[DP]['remaining_B']),
        'sd_remaining_B': statistics.stdev(data_dict[DP]['remaining_B']),
        'avg_delta_A': statistics.mean(data_dict[DP]['delta_A']),
        'sd_delta_A': statistics.stdev(data_dict[DP]['delta_A']),
        'avg_delta_B': statistics.mean(data_dict[DP]['delta_B']),
        'sd_delta_B': statistics.stdev(data_dict[DP]['delta_B']),
        'FER': FER_across_DP(data_dict, DP),
        'avg_total_wins_A': statistics.mean(data_dict[DP]['total_wins_A']),
        'sd_total_wins_A': statistics.stdev(data_dict[DP]['total_wins_A']),
        'avg_total_wins_B': statistics.mean(data_dict[DP]['total_wins_B']),
        'sd_total_wins_B': statistics.stdev(data_dict[DP]['total_wins_B']),
        'avg_total_exchanges': statistics.mean(data_dict[DP]['total_exchanges']),
        'sd_total_exchanges': statistics.stdev(data_dict[DP]['total_exchanges']),
        'prop_A_wins_exchanges': sum(data_dict[DP]['total_wins_A'])/sum(data_dict[DP]['total_exchanges']),
        'prop_B_wins_exchanges': sum(data_dict[DP]['total_wins_B'])/sum(data_dict[DP]['total_exchanges']),
        'prop_A_wins_overall': sum(data_dict[DP]['winner_A'])/len(data_dict[DP]['winner_A']),
        'prop_B_wins_overall': sum(data_dict[DP]['winner_B'])/len(data_dict[DP]['winner_B']),
        'prop_tie_overall': sum(data_dict[DP]['tie'])/len(data_dict[DP]['tie'])
    }
    outputs.append(data)

df_DOE = pd.read_csv(f'/home/{user_name}/Salvo_outputs/sim_DOE.csv')
df_DOE.index += 1
df_DOE['delta_0'] = df_DOE['A_0'] - df_DOE['B_0']
cols = df_DOE.columns.tolist()
new_order = [cols[-1]] + cols[:-1]
df_DOE = df_DOE[new_order]

df = pd.DataFrame(outputs)
merged_df = df_DOE.merge(df, left_index=True, right_on='index', how='left')

merged_df.to_csv(f'/home/{user_name}/Salvo_outputs/sim_DOE_results_Salvo_Modified_Stoch.csv', header=True, index=False)
