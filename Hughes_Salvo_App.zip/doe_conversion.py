import pandas as pd
import xlwings as xw

def ranges_2_parameters(min, max, levels):
    y = (max - min)/(levels - 1)
    x = min/y
    return round(x,2), round(y,2)


"""
# Can you try to use this in the streamlit app?
A_val = st.slider("Initial A Force", 0, 10000, (10,20))
alpha = st.slider("Well aimed missiles fired by A", 0, 100, (4,10))
a1_val = st.slider("number of hits by B's missiles needed to put one A unit out of action", 0, 100, (3,6))
a3_val = st.slider("number of well aimed missiles destroyed by each A", 0, 100, (2,4))
a4_val = st.slider("probability that accurate shots miss after counterfire by the enemy has failed A", 0, 1, (0.5,0.8))
sigmaA_val = st.slider("Scouting Effectiveness A", 0, 1, (0.9,1))
tauA_val = st.slider("Training Effectiveness A", 0, 1, (0.9,1))
delA_val = st.slider("Alertness of Defenses A", 0, 1, (0.9,1))
phiA_val = st.slider("Alertness of Chaff A", 0, 1, (0.9,1))
p_A_WAM_val = st.slider("Probability of a Missile Being Accurately Aimed on a Force B Target", 0, 1, (0.9,1))
p_A_DWAM_val = st.slider("Probability of a Missile Fired by Force B is Destroyed", 0, 1, (0.9,1))

B_val = st.slider("Initial B Force", 0, 10000, (10,20))
beta = st.slider("Well aimed missiles fired by B", 0, 100, (4,10))
b1_val = st.slider("number of hits by A's missiles needed to put one B unit out of action", 0, 100, (3,6))
b3_val = st.slider("number of well aimed missiles destroyed by each B", 0, 100, (2,4))
b4_val = st.slider("probability that accurate shots miss after counterfire by the enemy has failed B", 0, 1, (0.5,0.8))
sigmaB_val = st.slider("Scouting Effectiveness B", 0, 1, (0.9,1))
tauB_val = st.slider("Training Effectiveness B", 0, 1, (0.9,1))
delB_val = st.slider("Alertness of Defenses B", 0, 1, (0.9,1))
phiB_val = st.slider("Alertness of Chaff B", 0, 1, (0.9,1))
p_B_WAM_val = st.slider("Probability of a Missile Being Accurately Aimed on a Force A Target", 0, 1, (0.9,1))
p_B_DWAM_val = st.slider("Probability of a Missile Fired by Force A is Destroyed", 0, 1, (0.9,1))
"""


# Example of the min/max values that will get input into the DOE
A_val = (10,20)
alpha = (4,10)
a1_val = (3,6)
a3_val = (2,4)
a4_val = (0.5,0.8)
sigmaA_val = (0.9,1)
tauA_val = (0.9,1)
delA_val = (0.9,1)
phiA_val = (0.9,1)
p_A_WAM_val = (0.9,1)
p_A_DWAM_val = (0.9,1)

B_val = (10,20)
beta = (4,10)
b1_val = (3,6)
b3_val = (2,4)
b4_val = (0.5,0.8)
sigmaB_val = (0.9,1)
tauB_val = (0.9,1)
delB_val = (0.9,1)
phiB_val = (0.9,1)
p_B_WAM_val = (0.9,1)
p_B_DWAM_val = (0.9,1)
# End of example (Can be deleted when added to streamlit app)

A_val = ranges_2_parameters(A_val[0],A_val[1],100)
alpha = ranges_2_parameters(alpha[0],alpha[1],5)
a1_val = ranges_2_parameters(a1_val[0],a1_val[1],5)
a3_val = ranges_2_parameters(a3_val[0],a3_val[1],5)

B_val = ranges_2_parameters(B_val[0],B_val[1],100)
beta = ranges_2_parameters(beta[0],beta[1],5)
b1_val = ranges_2_parameters(b1_val[0],b1_val[1],5)
b3_val = ranges_2_parameters(b3_val[0],b3_val[1],5)

# Open the workbook
wb = xw.Book('DOE.xlsx')  # Replace with your file path
ws = wb.sheets['Translated Design']  # Replace with your sheet name

# Assign values to the cells
ws['B4'].value = alpha[0]
ws['B6'].value = alpha[1]
ws['C4'].value = beta[0]
ws['C6'].value = beta[1]
ws['D4'].value = a1_val[0]
ws['D6'].value = a1_val[1]
ws['E4'].value = b1_val[0]
ws['E6'].value = b1_val[1]
ws['F4'].value = a3_val[0]
ws['F6'].value = a3_val[1]
ws['G4'].value = b3_val[0]
ws['G6'].value = b3_val[1]
ws['H4'].value = A_val[0]
ws['H6'].value = A_val[1]
ws['I4'].value = B_val[0]
ws['I6'].value = B_val[1]

ws['J4'].value = a4_val[1]
ws['J5'].value = a4_val[0]
ws['K4'].value = b4_val[1]
ws['K5'].value = b4_val[0]
ws['L4'].value = sigmaA_val[1]
ws['L5'].value = sigmaA_val[0]
ws['M4'].value = sigmaB_val[1]
ws['M5'].value = sigmaB_val[0]
ws['N4'].value = tauA_val[1]
ws['N5'].value = tauA_val[0]
ws['O4'].value = tauB_val[1]
ws['O5'].value = tauB_val[0]
ws['P4'].value = delA_val[1]
ws['P5'].value = delA_val[0]
ws['Q4'].value = delB_val[1]
ws['Q5'].value = delB_val[0]
ws['R4'].value = phiA_val[1]
ws['R5'].value = phiA_val[0]
ws['S4'].value = phiB_val[1]
ws['S5'].value = phiB_val[0]
ws['T4'].value = p_A_WAM_val[1]
ws['T5'].value = p_A_WAM_val[0]
ws['U4'].value = p_B_WAM_val[1]
ws['U5'].value = p_B_WAM_val[0]
ws['V4'].value = p_A_DWAM_val[1]
ws['V5'].value = p_A_DWAM_val[0]
ws['W4'].value = p_B_DWAM_val[1]
ws['W5'].value = p_B_DWAM_val[0]

# Get all values from the worksheet
data = ws.range('B7:W2007').expand().value  # Adjust the range as necessary

# Convert to DataFrame
columns = data[0]  # The first row as the header
df = pd.DataFrame(data[1:], columns=columns)  # Create DataFrame from the data excluding the header

# Close the workbook
wb.close()

# Now df contains the evaluated values

# %%
df.to_csv('sim_DOE.csv', index=False)

# %%



